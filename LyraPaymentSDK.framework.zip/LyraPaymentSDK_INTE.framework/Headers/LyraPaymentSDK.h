//
//  LyraPaymentSDK.h
//  LyraPaymentSDK
//
//  Created by Lyra Network on 15/10/2018.
//  Copyright © 2018 Lyra Network. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LyraPaymentSDK.
FOUNDATION_EXPORT double LyraPaymentSDKVersionNumber;

//! Project version string for LyraPaymentSDK.
FOUNDATION_EXPORT const unsigned char LyraPaymentSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LyraPaymentSDK/PublicHeader.h>

